"use client";
import Layout from "@/components/layout/Layout";
import Link from "next/link";
import { useState } from "react";
export default function Register() {
  const [flatTabs, setFlatTabs] = useState(1);
  const handleFlatTabs = (index) => {
    setFlatTabs(index);
  };
  const [passwordVisible, setPasswordVisible] = useState(false);
  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };
  return (
    <>
      <Layout headerStyle={1} footerStyle={1}>
        <div>
          <section className="register login">
            <div className="container">
              <div className="row">
                <div className="col-md-12 d-flex align-items-center flex-wrap">
                  <div className="register_left col-md-5">
                    <h3 className="heading auth_left_col text-center">
                      USDT Bonanza
                    </h3>
                    <div className="">
                      <h4>
                        Upto <span>5 Million</span> People
                      </h4>

                      <div className="register_achive_cols">
                        <div>
                          <h5>Received User</h5>
                          <h6>204+</h6>
                        </div>
                        <div>
                          <h5>Balance User</h5>
                          <h6>4999796</h6>
                        </div>
                      </div>
                    </div>
                    <div className="">
                      <h4>
                        Upto <span>12.5 Million</span> USDT’s
                      </h4>

                      <div className="register_achive_cols">
                        <div>
                          <h5>Received USDT</h5>
                          <h6>5100</h6>
                        </div>
                        <div>
                          <h5>Balance USDT</h5>
                          <h6>124994900</h6>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-md-1"></div>
                  <div className="flat-tabs col-md-4">
                    <div className="content-tab">
                      <div className="content-inner">
                        <h3 className="heading mb-4">Sign up to Ultrapro</h3>
                        <div className="tabs_row">
                          <ul class="menu-tab">
                            <li className="active">
                              <h6 className="">Sign Up</h6>
                            </li>
                            <li>
                              <h6>Sign In</h6>
                            </li>
                          </ul>
                        </div>

                        <form className="authform">
                          <div className="form-group">
                            <label>Name</label>
                            <input
                              type="text"
                              className="form-control"
                              placeholder="Enter Name"
                            />
                          </div>

                          <div className="form-row fields">
                            <div className="form-group">
                              <label>Country</label>
                              <select className="form-control">
                                <option>India (+91)</option>
                                <option>Vietnamese (+84)</option>
                                <option>United Arab Emirates (+71)</option>
                                <option>South Korea (+82)</option>
                              </select>
                            </div>
                            <div className="form-group">
                              <label>Phone</label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="+91- 99999-99999"
                              />
                            </div>
                          </div>
                          <div className="form-group">
                            <label htmlFor="exampleInputEmail1">Email</label>
                            <input
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Please fill in the email form."
                            />
                          </div>
                          <div className="form-group">
                            <label>Password</label>
                            <input
                              type="password"
                              className="form-control"
                              placeholder="Please enter a password."
                            />
                          </div>
                          <div className="form-group">
                            <label>Confirm Password</label>
                            <input
                              type="password"
                              className="form-control"
                              placeholder="Please re-enter your password."
                            />
                          </div>

                          <div className="form-group">
                            <label>Referral Id (optional) </label>
                            <input
                              type="text"
                              className="form-control"
                              placeholder="Please enter your invitation code."
                            />
                          </div>

                          <div className="form-group">
                            {/* <label>Referral Id (optional) </label> */}
                            <div
                              className="d-flex align-items-center"
                              style={{ gap: "10px" }}
                            >
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <label
                                className="form-check-label mb-0"
                                style={{ color: "#7A86A1" }}
                              >
                                I accept the Terms and Conditions
                              </label>
                            </div>
                          </div>
                          <button type="submit" className="btn-action">
                            <img src="/assets/images/giftbox.svg" /> Create
                            Account and Earn 25 USDT
                          </button>
                          {/* <div className="bottom">
                            <p>Already have an account?</p>
                            <Link href="/login">Login</Link>
                          </div> */}
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </Layout>
    </>
  );
}
