"use client";
import Layout from "@/components/layout/Layout";
import Link from "next/link";
import { useState } from "react";

export default function forgotPassword() {
  const [flatTabs, setFlatTabs] = useState(1);
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleFlatTabs = (index) => {
    setFlatTabs(index);
  };

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  return (
    <>
      <Layout>
        <div>
          <section className="register login">
            <div className="container">
              <div className="row">
                <div className="col-md-12 d-flex align-items-center flex-wrap">
                  <div className="center col-md-5">
                    <h3 className="heading auth_left_col">
                      <span>Trade</span> on the go. <br />
                      Anywhere, anytime.
                    </h3>
                    <div className="d-flex auth_left_col_image">
                      <div className="ph_img">
                        <img src="/assets/images/ph-img-signin.svg" />
                      </div>
                      <div className="qrcode_panel">
                        <img src="/assets/images/canopro_qrcode.png" alt="" />
                        <p>Scan to Download App</p>
                        <img src="/assets/images/app-store.svg" />
                      </div>
                    </div>
                  </div>
                  <div className="col-md-1"></div>
                  <div className="flat-tabs col-md-4">
                    <div className="content-tab">
                      <div className="content-inner">
                        <h3 className="heading mb-4">Forgot Password?</h3>

                        <div className="row">
                          <div className="col-md-12">
                            <div className="block-text">
                              <p className="forgot_description">
                                Enter the email address you used when you joined
                                and we'll send you instructions to reset your
                                password.
                              </p>
                            </div>
                          </div>
                        </div>
                        <form className="authform">
                          <div className="form-group">
                            <label htmlFor="exampleInputEmail1">
                              Email Address
                            </label>
                            <input
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Enter your Mail ID"
                            />
                          </div>
                          <button type="submit" className="btn-action">
                            Reset Password
                          </button>
                          <div className="back_link">
                            <Link href="/login">Back to login</Link>
                          </div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </Layout>
    </>
  );
}
