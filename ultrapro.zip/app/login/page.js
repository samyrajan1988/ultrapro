"use client";
import Layout from "@/components/layout/Layout";
import Link from "next/link";
import { useState } from "react";

export default function Login() {
  const [flatTabs, setFlatTabs] = useState(1);
  const [passwordVisible, setPasswordVisible] = useState(false);

  const handleFlatTabs = (index) => {
    setFlatTabs(index);
  };

  const togglePasswordVisibility = () => {
    setPasswordVisible(!passwordVisible);
  };

  return (
    <>
      <Layout>
        <div>
          <section className="register login">
            <div className="container">
              <div className="row">
                <div className="col-md-12 d-flex flex-wrap">
                  <div className="center col-md-5 col-xs-12">
                    <h3 className="heading auth_left_col">
                      <span>Trade</span> on the go. <br />
                      Anywhere, anytime.
                    </h3>
                    <div className="d-flex auth_left_col_image">
                      <div className="ph_img">
                        <img src="/assets/images/ph-img-signin.svg" />
                      </div>
                      <div className="qrcode_panel">
                        <img src="/assets/images/canopro_qrcode.png" alt="" />
                        <p>Scan to Download App</p>
                        <img src="/assets/images/app-store.svg" />
                      </div>
                    </div>
                  </div>
                  <div className="col-md-1 col-xs-hidden"></div>
                  <div className="flat-tabs col-md-4 col-xs-12">
                    <div className="content-tab">
                      <div className="content-inner">
                        <h3 className="heading mb-4">Login to Ultrapro</h3>
                        <div className="tabs_row">
                          <ul class="menu-tab">
                            <li className="active">
                              <h6>Sign In</h6>
                            </li>
                            <li>
                              <h6 className="">Sign Up</h6>
                            </li>
                          </ul>
                        </div>
                        <div className="row">
                          <div className="col-md-12">
                            <div className="block-text">
                              <div className="lock">
                                <div className="">
                                  <img src="assets/images/login-icon.svg" />
                                </div>
                                <div>
                                  <span>Check if your URL is correct</span>
                                  <p>
                                    <img src="assets/images/lock.svg" />
                                    <span>https://</span>www.ultraproex.com
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <form className="authform">
                          <div className="form-group">
                            <label htmlFor="exampleInputEmail1">
                              Email Address
                            </label>
                            <input
                              type="email"
                              className="form-control"
                              id="exampleInputEmail1"
                              placeholder="Enter your Mail ID"
                            />
                          </div>
                          <div className="form-group s1">
                            <label>Password </label>
                            <div className="input-group">
                              <input
                                type={passwordVisible ? "text" : "password"}
                                className="form-control"
                                placeholder="Enter 8 digit password"
                              />
                              <div className="input-group-append">
                                <img
                                  src={
                                    passwordVisible
                                      ? "/assets/images/eye_open.svg"
                                      : "/assets/images/eye_closed.svg"
                                  }
                                  alt="Toggle Password Visibility"
                                  style={{ cursor: "pointer" }}
                                  onClick={togglePasswordVisibility}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="form-group form-check">
                            <div>
                              <input
                                type="checkbox"
                                className="form-check-input"
                              />
                              <label className="form-check-label">
                                Remember Me
                              </label>
                            </div>
                            <Link href="forgotPassword">Forgot Password?</Link>
                          </div>
                          <button type="submit" className="btn-action">
                            Login
                          </button>
                          {/* <div className="bottom">
                            <p>Not a member?</p>
                            <Link href="/register">Register</Link>
                          </div> */}
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </Layout>
    </>
  );
}
